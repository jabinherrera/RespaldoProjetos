public interface Mostrable {
    void mostrarCartas();
}