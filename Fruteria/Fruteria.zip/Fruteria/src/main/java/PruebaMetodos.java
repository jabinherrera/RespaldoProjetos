import java.sql.*;
import java.util.ArrayList;

public class PruebaMetodos {
    static final String DB_URL = "jdbc:mysql://localhost/fruteria";
    static final String USER = "User";
    static final String PASS = "123qwerty";



    public static void main(String[] args) {
        GestorArchivo ga1  = new GestorArchivo();
        //ga1.crearArchivo("uwu.txt","");
        String[] ruts = ga1.leerArchivo("rut.txt").split("\n");
        for (String r : ruts) {
            System.out.println(r);
        }



    }
}
